#include "prodWorker.h"



prodWorker::prodWorker()
{
}


prodWorker::~prodWorker()
{
}
