#include "employee.h"



employee::employee()
{
}


employee::~employee()
{
}
