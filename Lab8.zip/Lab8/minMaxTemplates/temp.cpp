#include "stdafx.h"
#include "temp.h"


temp::temp()
{
}


temp::~temp()
{
}
